from django.apps import AppConfig


class MyformFormConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myform_form'
